function decodestatus(status){
	if(status==0){
		var status="New";
		return status;
	}
	else if(status==1){
		var status="Approved";
		return status;
	}
	else if(status==2){
		var status="Financed";
		return status;
	}
	else if(status==3){
		var status="Settled";
		return status;
	}
	else if(status==4){
		var status="Rejected";
		return status;
	}
	
}
