// Userlist data array for filling in info box
var invoiceListData = [];
// DOM Ready =============================================================
$(document).ready(function() {

    // Populate the user table on initial page load
    populateTable();
	populatebanklist();
	$('#btnApproveInvoice').on('click', approveFinance);

});

// Functions =============================================================

function approveFinance(event){
    var errorCount = 0;
    var bank=$('#BankList :selected').val();
	var radio= $('#invoiceList input[name=invoice]:checked').val();
	if(bank=='0x00' || radio==undefined){
		errorCount++;
	}
	if (errorCount===0){
        // Use AJAX to post the object 
		
        var data = {
            'invoiceId': radio,
            'bankaddress': bank
        }
        $.ajax({
            type: 'POST',
            data: data,
            url: 'approve/approveinvoice',
            dataType: 'JSON'
        }).done(function( response ) {

            // Check for successful (blank) response
                       var str=response.msg;
                        // Check for successful (blank) response
                        if (str.startsWith("Error")){
						// If something goes wrong, alert the error message that our service returned
							alert(response.msg);
                                
                        }
                        else {
                                
								alert("The invoice has been approved successfully.\nEthereum transaction number is: " + response.msg);
                                
                        }
        });
	}
	else {
        // If errorCount is more than 0, error out
		if(bank==='0x00'){
			alert('Please select bank');
		}
			alert('Please select invoice');
        return false;
    }
}

function populatebanklist() {
	var banklist='';
	banklist+= '<option value= "0x00"> Kindly Select Bank </option>';
	    $.getJSON( '/scf/approve/banklist', function( data ) {
        // For each item in our JSON, add a table row and cells to the content string
        $.each(data, function(){
		   
            banklist += '<option'+" "+'value='+'"'+ this.ethAddress +'"'+'>'+this.name + '</option>';
        });

        // Inject the whole content string into our existing HTML table
        $('#BankList select').html(banklist);
    });
	
}
// Fill table with data
function populateTable() {

    // Empty content string
    var tableContent = '';
	
    // jQuery AJAX call for JSON
    $.getJSON( '/scf/approve/invoicelist', function( data ) {
		
        // For each item in our JSON, add a table row and cells to the content string
        $.each(data, function(){
			var status=decodestatus(this.status);
            tableContent += '<tr>'+'<td>'+'<input type="radio" name="invoice"'+'value='+this.invoiceId+'>'+'</td>';
            //tableContent += '<td><a href="#" class="linkshowuser" rel="' + this.username + '">' + this.username + '</a></td>';
            tableContent += '<td>' + this.invoiceId + '</td>';
	        tableContent += '<td>' + this.invoiceReference + '</td>';
            tableContent += '<td>' + this.supplier + '</td>';
            tableContent += '<td>' + this.buyer + '</td>';
            tableContent += '<td>' + this.amount + '</td>';
            tableContent += '<td>' + status + '</td>';
            //tableContent += '<td><a href="#" class="linkdeleteuser" rel="' + this._id + '">delete</a></td>';
            tableContent += '</tr>';
        });

        // Inject the whole content string into our existing HTML table
        $('#invoiceList table tbody').html(tableContent);
    });
};
