// DOM Ready =============================================================

$(document).ready(function() {

    // Populate the user table on initial page load
    populateTable();
	$('#btnFinanceInvoice').on('click', financeinvoice);

});

function financeinvoice(event){
    var errorCount = 0;


	var radio= $('#invoiceList input[name=invoice]:checked').val();
	var id= $('#invoiceList input[name=invoice]:checked').attr('id');
	var name= $('#invoiceList input[name=buyer'+id+']').val();
    var amount= $('#invoiceList input[name=amount'+id+']').val();
	if(radio==undefined){
		errorCount++;
	}
	if (errorCount===0){
        // Use AJAX to post the object 
		
        var data = {
        'invoiceId': radio,
	    'name': name,
	    'amount': amount
        }
        $.ajax({
            type: 'POST',
            data: data,
            url: 'finance/financeinvoice',
            dataType: 'JSON'
        }).done(function( response ) {

            // Check for successful (blank) response
			var str=response.msg;
            if(response.msg=== false){

                // If something goes wrong, alert the error message that our service returned
                alert('Error: Credit limit check failed due to insufficient limit' );

            }
			 else if (str.startsWith("Error")){
				// If something goes wrong, alert the error message that our service returned
				alert(response.msg);                                
            }
            else {                                
				alert("The invoice has been financed successfully.\nEthereum transaction number is: " + response.msg);                                
            }
        });
	}
	else {
        // If errorCount is more than 0, error out
        alert('Please select invoice');
        return false;
    }
}

// Fill table with data
function populateTable() {

    // Empty content string
    var tableContent = '';
	
    // jQuery AJAX call for JSON
    $.getJSON( '/scf/finance/invoicelist', function( data ) {
			var count=0;
        // For each item in our JSON, add a table row and cells to the content string
        $.each(data, function(){
			var status=decodestatus(this.status);
		
            tableContent += '<tr>'+'<td>'+'<input type="radio" id='+count+'  name="invoice"'+'value='+this.invoiceId+'>'+'</td>';            
            tableContent += '<td>' + this.invoiceId + '</td>';
			tableContent += '<td>' + this.invoiceReference + '</td>';
            tableContent += '<td>' + this.supplier + '</td>';
            tableContent += '<td>' +'<input type="hidden" name="buyer'+count+'"'+'value='+'"'+this.buyerEthId+'"'+'>'+this.buyer +'</td>';            
            tableContent += '<td>' +'<input type="hidden" name="amount'+count+'"'+'value='+'"'+this.amount+'"'+'>'+this.amount +'</td>';
            tableContent += '<td>' + status + '</td>';            
            tableContent += '</tr>';
			count++;
        });

        // Inject the whole content string into our existing HTML table
        $('#invoiceList table tbody').html(tableContent);
    });
};
