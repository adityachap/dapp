$(document).ready(function() {
	if(err && err == 1001){
		alert('Invalid User: No user exists with given address!');
	}
});

function validate(){	
	if(document.indexform.ethAddress.value === ''){
		alert('Please fill in Ethereum address.');
        	return false;
	}else if(document.indexform.method == 'get'){
		document.indexform.method = 'post'
	}

	document.indexform.action = '/scf/menu';
	document.indexform.submit();
}
