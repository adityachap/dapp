function operation(action){
	switch(action) {
		case 'create':
			document.menuform.action='/scf/create';
			break;
		case 'approve':
			document.menuform.action='/scf/approve';
			break;
		case 'finance':
			document.menuform.action='/scf/finance';
			break;
		case 'settle':
			document.menuform.action='/scf/settle';
			break;
		case 'view':
		default:
			document.menuform.action='/scf/view';
	}
	
	document.menuform.submit();
}
