$(document).ready(function() {
        var listDisplay = '';

        listDisplay += '<option value= "0x00"> Kindly Select Buyer </option>';
        $.getJSON( '/scf/create/userlist', function(data ) {
				if(data.msg != null && data.msg.startsWith("AuthenticationError")){
						alert(data.msg);
						return false;
				}
                // For each item in our JSON, add a table row and cells to the content string
                $.each(data, function(){
                        listDisplay += '<option'+" "+'value='+'"'+ this.ethAddress +'"'+'>'+this.name + '</option>';
                });

                // Inject the whole content string into our existing HTML table
                $('#UserList select').html(listDisplay);
        });
});

function validate(){
        var buyer=$('#UserList :selected').val();
        if(buyer === '0x00'){
                alert('Please select appropriate Buyer.');
        } else if(document.createform.amount.value === ''){
                alert('Please fill in Invoice Amount.');
        } else if(!(new RegExp('^\\d+$').test(document.createform.amount.value))){
                alert('Invoice Amount can only be a positive number.');
        } else if(document.createform.amount.value == 0){
                alert('Invoice Amount cannot be zero.');
        } else if(document.createform.invoiceReference.value === ''){
                alert('Please fill in Invoice Reference Number.');
        } else if(!(new RegExp('^\\d+$').test(document.createform.invoiceReference.value))){
                alert('Invoice Reference Number can only be numeric.');
        } else {
                var data = {
                        'invoiceReference': document.createform.invoiceReference.value,
                        'buyerEthAddress': buyer,
                        'amount': document.createform.amount.value
                }
                $.ajax({
                        type: 'POST',
                        data: data,
                        url: '/scf/status',
                        dataType: 'JSON'
                }).done(function( response ){
						var str=response.msg;
                        // Check for successful (blank) response
                        if (str.startsWith("Error")){
							// If something goes wrong, alert the error message that our service returned
							alert(response.msg);                                
                        }
                        else {
							// Display the transaction hash received
							alert("The invoice has been created successfully.\nEthereum transaction number is: " + response.msg);								 
                        }
                        document.createform.reset();
                });
        }
	return false;
}
