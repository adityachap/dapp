$(document).ready(function() {
        var listDisplay = '';

        if(suplIn.length > 0){
                listDisplay += '<br><h4> Invoices where you are the Supplier</h4>';
                listDisplay += '<table bgcolor="#1a1a1a",class="w3-opacity-min", style = "overflow-y:scroll;height:200px;width:300px;display:block;color:white;font-style:bold;">';
                suplIn.forEach(function(invoice){
                        listDisplay += '<tr>';
                        listDisplay += '<td><a href="#" class="linkshowinvoice" rel="' + invoice.id + '">' + invoice.ref + '</a></td>';
                        listDisplay += '</tr>';
                });
                listDisplay += '</table><br>';
        }

        if(buyIn.length > 0){
                listDisplay += '<br><h4> Invoices where you are the Buyer</h4>';
                listDisplay += '<table bgcolor="#1a1a1a",class="w3-opacity-min", style = "overflow-y:scroll;height:200px;width:300px;display:block;color:white;font-style:bold;">';
                buyIn.forEach(function(invoice){
                        listDisplay += '<tr>';
                        listDisplay += '<td><a href="#" class="linkshowinvoice" rel="' + invoice.id + '">' + invoice.ref + '</a></td>';
                        listDisplay += '</tr>';
                });
                listDisplay += '</table><br>';
        }

        if(bnkIn.length > 0){
                listDisplay += '<br><h4> Invoices where you are the Bank</h4>';
                listDisplay += '<table bgcolor="#1a1a1a",class="w3-opacity-min", style = "overflow-y:scroll;height:200px;width:300px;display:block;color:white;font-style:bold;">';
                bnkIn.forEach(function(invoice){
                        listDisplay += '<tr>';
                        listDisplay += '<td><a href="#" class="linkshowinvoice" rel="' + invoice.id + '">' + invoice.ref + '</a></td>';
                        listDisplay += '</tr>';
                });
                listDisplay += '</table></br>';
        }
        $('#invoicelist').html(listDisplay);

        $('#invoicelist').on('click', 'td a.linkshowinvoice', showInvoiceInfo);
});

function showInvoiceInfo(event){
        event.preventDefault();
        var invoiceId = $(this).attr('rel');
                var data = {
        'invoiceId': invoiceId
        }
                 $.ajax({
            type: 'POST',
            data: data,
            url: 'view/viewinvoice',
            dataType: 'JSON'
        }).done(function( response ) {
            if (response.msg){
                // If something goes wrong, alert the error message that our service returned
                alert(response.msg);
			} else{
				var status=decodestatus(response[7]);
                //Populate Info Box
                $('#invoiceInfoId').text(response[1]);
                $('#invoiceInfoReference').text(response[6]);
                $('#invoiceInfoSupplier').text(response[2]);
                $('#invoiceInfoBuyer').text(response[3]);
                $('#invoiceInfoBank').text(response[4]);
                $('#invoiceInfoAmount').text(response[5]);
                $('#invoiceInfoStatus').text(status);

                $.ajax({
                    type: 'POST',
                    data: data,
                    url: 'view/viewhistory',
                    dataType: 'JSON'
                }).done(function( result ) {
                        if (result.msg){
                            // If something goes wrong, alert the error message that our service returned
                            alert(result.msg);
                        } else{
                            $('#invoiceInfoCreateDate').text(result.createdate);
                            $('#invoiceInfoApproveDate').text(result.approvedate);
                            (response[7] == 2 || response[7] == 3)? $('#invoiceInfoFinanceDate').text(result.financedate) : $('#invoiceInfoFinanceDate').text('  NA  ');
                            $('#invoiceInfoSettleDate').text(result.settledate);
                            (response[7] == 4)? $('#invoiceInfoRejectDate').text(result.financedate) : $('#invoiceInfoRejectDate').text('  NA  ');
                        }
				});
			}
        });
};
