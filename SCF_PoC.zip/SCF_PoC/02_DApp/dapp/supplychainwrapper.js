var Web3 = require('web3');
var mongo = require('mongodb');
var monk = require('monk');
var db = monk('localhost:27017/supplychaindb');
web3 = new Web3(new Web3.providers.HttpProvider("http://localhost:8020"));
var supplychainContract = web3.eth.contract([{"constant":false,"inputs":[{"name":"bank","type":"address"},{"name":"ledgerinvoicenumber","type":"uint256"}],"name":"approveInvoice","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"buyer","type":"address"},{"name":"amount","type":"int256"},{"name":"invoice_number","type":"uint256"}],"name":"createInvoice","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"","type":"uint256"}],"name":"invoices","outputs":[{"name":"invoiceId","type":"uint256"},{"name":"supplier","type":"address"},{"name":"buyer","type":"address"},{"name":"bank","type":"address"},{"name":"amount","type":"int256"},{"name":"invoice_number","type":"uint256"},{"name":"status","type":"uint8"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"flag","type":"bool"},{"name":"ledgerinvoicenumber","type":"uint256"}],"name":"settleInvoice","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"flag","type":"bool"},{"name":"ledgerinvoicenumber","type":"uint256"}],"name":"financeInvoice","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"ino","type":"uint256"}],"name":"viewInvoice","outputs":[{"name":"result","type":"bool"},{"name":"invoiceId","type":"uint256"},{"name":"supplier","type":"address"},{"name":"buyer","type":"address"},{"name":"bank","type":"address"},{"name":"amount","type":"int256"},{"name":"invoice_number","type":"uint256"},{"name":"status","type":"uint8"}],"payable":false,"stateMutability":"view","type":"function"},{"inputs":[],"payable":false,"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"name":"supplier","type":"address"},{"indexed":true,"name":"buyer","type":"address"},{"indexed":true,"name":"bank","type":"address"},{"indexed":false,"name":"amount","type":"int256"},{"indexed":false,"name":"currentInvoiceId","type":"uint256"},{"indexed":false,"name":"invoice_number","type":"uint256"},{"indexed":false,"name":"status","type":"uint8"},{"indexed":false,"name":"datetime","type":"uint256"}],"name":"InvoiceCreated","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"supplier","type":"address"},{"indexed":true,"name":"buyer","type":"address"},{"indexed":true,"name":"bank","type":"address"},{"indexed":false,"name":"ledgerinvoicenumber","type":"uint256"},{"indexed":false,"name":"status","type":"uint8"},{"indexed":false,"name":"datetime","type":"uint256"}],"name":"InvoiceApproved","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"supplier","type":"address"},{"indexed":true,"name":"buyer","type":"address"},{"indexed":true,"name":"bank","type":"address"},{"indexed":false,"name":"ledgerinvoicenumber","type":"uint256"},{"indexed":false,"name":"status","type":"uint8"},{"indexed":false,"name":"datetime","type":"uint256"}],"name":"InvoiceFinanced","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"supplier","type":"address"},{"indexed":true,"name":"buyer","type":"address"},{"indexed":true,"name":"bank","type":"address"},{"indexed":false,"name":"ledgerinvoicenumber","type":"uint256"},{"indexed":false,"name":"status","type":"uint8"},{"indexed":false,"name":"datetime","type":"uint256"}],"name":"InvoiceSettled","type":"event"}]).at("0x478725ae3c0837a49232e6f403ba02d564dae68f");
var currentInvoiceId;
var removed=false;
var accounts=web3.eth.accounts;
var currentstatus=-1;
var lastSyncedBlock=db.get('lastsyncedblock');
function checkAccounts(supplier,buyer,bank){
	if(accounts.indexOf(supplier)!==-1){
		return true;
	}
	else if(accounts.indexOf(buyer)!==-1){
		return true;
	}
	else if(accounts.indexOf(bank)!==-1){
		return true;
	}
	else{
		return false;
	}
}
lastSyncedBlock.findOne({},{},function(error,result){
	if(error){
		return console.error(error);
	}
	if(result){
				var	fromBlock = result.blockNumber; 
				console.log(fromBlock);
				var allEvents = supplychainContract.allEvents({fromBlock: fromBlock+1 , toBlock: 'latest'});
                allEvents.watch(function(error, result){
                        if (!error){			
							removed=result.removed;
							if(checkAccounts(result.args.supplier,result.args.buyer,result.args.bank))	{
								if(result.event==="InvoiceCreated"){
									console.log(result);
									currentInvoiceId=result.args.currentInvoiceId.c;
									currentstatus=result.args.status.c;
									var utcSeconds=Number(result.args.datetime.c);
									var createdate = new Date(0); // The 0 there is the key, which sets the date to the epoch
									createdate.setUTCSeconds(utcSeconds);
									if(currentstatus==0){
										var invoices=db.get('invoices');
										if(!removed){
											invoices.insert({'invoiceId' : currentInvoiceId, 'invoiceReference' : result.args.invoice_number.c, 'supplier' : result.args.supplier, 'buyer' : result.args.buyer, 'bank' : result.args.bank, 'amount' : result.args.amount.c, 'status' : currentstatus,'createdate':createdate,'approvedate': '','financedate': '','settledate': ''},function(err,result){
											console.log('success created');
											});
										}
										else{
											invoices.remove({'invoiceId' : currentInvoiceId},function(err,result){
												console.log('success deleted for chain reorganization scenario');
												});
										}
									}								
								} else if(result.event==="InvoiceApproved"){
									console.log(result);
									currentInvoiceId=result.args.ledgerinvoicenumber.c;
									currentstatus=result.args.status.c;
									var utcSeconds=Number(result.args.datetime.c);
									var approvedate = new Date(0); // The 0 there is the key, which sets the date to the epoch
									approvedate.setUTCSeconds(utcSeconds);
									if(currentstatus==1){
										var invoices=db.get('invoices');
										invoices.update({invoiceId:currentInvoiceId},{$set:{bank:result.args.bank,status:currentstatus,approvedate: approvedate}}, function(err, result){
											console.log('success approve');
										});
								// lastSyncedBlock.update({},{$set:{blockNumber: result.blockNumber}});
									}
								} else if(result.event==="InvoiceFinanced"){
									console.log(result);
									currentInvoiceId=result.args.ledgerinvoicenumber.c;
									currentstatus=result.args.status.c;
									var utcSeconds=Number(result.args.datetime.c);
									var financedate = new Date(0); // The 0 there is the key, which sets the date to the epoch
									financedate.setUTCSeconds(utcSeconds);
									if(currentstatus==2){
                                        var invoices=db.get('invoices');
										invoices.update({invoiceId:currentInvoiceId},{$set:{status:currentstatus,financedate: financedate}}, function(err, result){
											console.log('success finance');
										});
										// lastSyncedBlock.update({},{$set:{blockNumber: result.blockNumber}});
									} else if(currentstatus==4) {
                                        var invoices=db.get('invoices');
										invoices.update({invoiceId:currentInvoiceId},{$set:{status:currentstatus,financedate: financedate}}, function(err, result){
											console.log('success Reject');
										});
										// lastSyncedBlock.update({},{$set:{blockNumber: result.blockNumber}});							
									}						
								} else if(result.event==="InvoiceSettled"){	
									console.log(result);
									currentInvoiceId=result.args.ledgerinvoicenumber.c;
									currentstatus=result.args.status.c;
									var utcSeconds=Number(result.args.datetime.c);
									var settledate = new Date(0); // The 0 there is the key, which sets the date to the epoch
									settledate.setUTCSeconds(utcSeconds);
									if(currentstatus==3){
										var invoices=db.get('invoices');
										invoices.update({invoiceId:currentInvoiceId},{$set:{status:currentstatus,settledate: settledate}}, function(err, result){
											console.log('success settle');
										});										
									}
								}								
							}
							if(!removed){
								lastSyncedBlock.update({},{$set:{blockNumber: result.blockNumber}});
							}

						}
                });

		
	} 
});


exports.createInvoice=function(buyer,amount,invRef,currentUserAddress,fn){
        supplychainContract.createInvoice(buyer,amount,invRef, {from: currentUserAddress,gas:"1500000"},function(error,result){
			
			fn(error,result);
		});
                
}
exports.approveInvoice=function (currentUserAddress,ledgerinvoice_number,bank,fn){
                console.log("approving invoice");
        supplychainContract.approveInvoice(bank,ledgerinvoice_number, {from: currentUserAddress,gas:"1500000"},function(error,result){
			fn(error,result);
		});

}

exports.financeInvoice=function (currentUserAddress,ledgerinvoice_number,bool,fn){
                console.log("bank is financing the invoice");
		supplychainContract.financeInvoice(bool,ledgerinvoice_number, {from: currentUserAddress,gas:"1500000"},function(error,result){
			fn(error,result);
		});

}

exports.settleInvoice=function (currentUserAddress,ledgerinvoice_number,bool,fn){
                console.log("bank is settling the invoice");
        supplychainContract.settleInvoice(bool,ledgerinvoice_number, {from: currentUserAddress,gas:"1500000"},function(error,result){
			fn(error,result);
		});

}
exports.viewInvoice=function(invoiceid,fn){
                console.log("view request received getting invoice from ledger");
                supplychainContract.viewInvoice(Number(invoiceid),function(error,result){
					fn(error,result);
                });

}
