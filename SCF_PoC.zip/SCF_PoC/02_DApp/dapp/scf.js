var express = require('express');
var router = express.Router();
var creditcheck= require('creditlimit');
var monk = require('monk');
var Web3 = require('web3');
var wrapper= require('./supplychainwrapper');
var bodyParser = require('body-parser'); //parses information from POST

var mongoip='172.43.2.170'; //Ip address of server where Mongo DB instance for credit limit database is present

router.use(bodyParser.urlencoded({ extended: true }))

router.route('/')
        .get(function(req,res,next) {
                res.format({
                        html: function(){
                                var q= req.url.split('?');
                                if(q.length >= 2){
                                        var first = q[1].split('&')[0].split('=');
                                        if(first[0] == 'error'){
                                                res.render('scf/index', {title: 'SCF', errorCode: '1001'});
                                        }
                                } else {
                                        res.render('scf/index', {title: 'SCF'});
                                }
                        }
                });
        });

router.post('/menu', function(req, res) {
        if(req.headers.referer.split('?')[0].endsWith("/scf")){
                var ethAddr = req.body.ethAddress;
                var db = req.db;
                var users = db.get('dappusers');
                var banks =db.get('banks');

                users.findOne({ethAddress: ethAddr}, {name: 1}, function(err, doc){
                        if(err){
                                return console.error(err);
                        }

                        if(!doc){
                                banks.findOne({ethAddress: ethAddr},{name: 1}, function(err,doc) {
                                        if(err){
                                                return console.error(err);
                                        }

                                        if(!doc){
                                                res.redirect('/scf?error=1001');
                                        }else {
                                                var currentUserName = doc.name;
                                                req.scfSession.userName = currentUserName;
                                                req.scfSession.userAddress = ethAddr;
                                                res.render('scf/menu', { title: 'SCF', name: currentUserName });
                                        }
                                });
                        } else{
                                var currentUserName = doc.name;
                                req.scfSession.userName = currentUserName;
                                req.scfSession.userAddress = ethAddr;
                                res.render('scf/menu', { title: 'SCF', name: currentUserName });
                        }
                });
        } else{
                res.render('scf/menu', { title: 'SCF', name: req.scfSession.userName });
        }
});

router.post('/create', function(req, res) {
        var currentUserName = req.scfSession.userName;
        var currentUserAddress = req.scfSession.userAddress;

        res.render('scf/create', { title: 'SCF', name: currentUserName, ethAddress: currentUserAddress});
});

router.get('/create/userlist',function(req,res) {
        var currentUserAddress = req.scfSession.userAddress;

        var db=req.db;
        var users=db.get('dappusers');
		
		users.findOne({ethAddress: currentUserAddress}, {ethAddress: 1}, function(err, doc){
			if(err){
				return console.error(err);
			}
			
			if(!doc){
				return res.send({msg:'AuthenticationError: You are not allowed to use this functionality.'});
			} else{
				users.find({ethAddress: { $ne: currentUserAddress} },{name: 1, ethAddress: 1},function(e,result){
					if(e){
                        return console.error(e);
					}
					if(result){
                        res.json(result);
					}
				});
			}
        });
});

router.post('/status', function(req, res) {
        var currentUserName = req.scfSession.userName;
        var currentUserAddress = req.scfSession.userAddress;
        var buyer = req.body.buyerEthAddress;
        var amount = Number(req.body.amount);
        var invRef = Number(req.body.invoiceReference);

        wrapper.createInvoice(buyer,amount,invRef,currentUserAddress,function(error,result){
                if(!error){
						
                        res.send({msg:result});
                } else{
                        res.send({msg:'Error: '+ error.message});
                }
        });
});

router.post('/view', function(req, res) {
        var currentUserName = req.scfSession.userName;
        var currentUserAddress = req.scfSession.userAddress;

        var db = req.db;
        var invoices = db.get('invoices');
        var users = db.get('dappusers');
        var banks = db.get('banks');

        var supplierInvoices = [];
        var buyerInvoices = [];
        var bankInvoices = [];

        users.findOne({ethAddress: currentUserAddress}, {name: 1}, function(err, docs){
                if(err){
                        return console.error(err);
                }

                if(!docs){
                        banks.findOne({ethAddress: currentUserAddress},{name: 1}, function(err,doc) {
                                if(err){
                                        return console.error(err);
                                }
                                if(doc){
                                        invoices.find({bank: currentUserAddress},{invoiceId: 1, invoiceReference:1}, function(err, docs){
                                                if(err){
                                                        return console.error(err);
                                                }

                                                if(docs){
                                                        docs.forEach( function(currDoc){
                                                                bankInvoices.push({id: currDoc.invoiceId, ref: currDoc.invoiceReference});
                                                        });
                                                }
                                                res.render('scf/view', { title: 'SCF', name: currentUserName, ethAddress: currentUserAddress, suplIn: supplierInvoices, buyIn: buyerInvoices, bnkIn: bankInvoices});
                                        });
                                }
                        });
                } else{
                        invoices.find({ $or: [{supplier: currentUserAddress},{buyer: currentUserAddress}]},{invoiceId: 1, invoiceReference: 1, supplier: 1}, function(err, docs){
                                if(err){
                                        return console.error(err);
                                }

                                if(docs){
                                        docs.forEach( function(currDoc){
                                                (currDoc.supplier == currentUserAddress) ? supplierInvoices.push({id: currDoc.invoiceId, ref: currDoc.invoiceReference}) : buyerInvoices.push({id: currDoc.invoiceId, ref: currDoc.invoiceReference});
                                        });
                                }
                                res.render('scf/view', { title: 'SCF', name: currentUserName, ethAddress: currentUserAddress, suplIn: supplierInvoices, buyIn: buyerInvoices, bnkIn: bankInvoices});
                        });
                }
        });
});

router.post('/approve', function(req, res) {
        var currentUserName = req.scfSession.userName;
        var currentUserAddress = req.scfSession.userAddress;

        res.render('scf/approve', { title: 'SCF', name: currentUserName, ethAddress: currentUserAddress});
});

router.post('/settle', function(req, res) {
        var currentUserName = req.scfSession.userName;
        var currentUserAddress = req.scfSession.userAddress;

        res.render('scf/settle', { title: 'SCF', name: currentUserName, ethAddress: currentUserAddress});
});

router.post('/finance', function(req, res) {
        var currentUserName = req.scfSession.userName;
        var currentUserAddress = req.scfSession.userAddress;

        res.render('scf/finance', { title: 'SCF', name: currentUserName, ethAddress: currentUserAddress});
});

/*
 * GET banklist.
 */
router.get('/approve/banklist',function(req,res){
        var db=req.db;
        var banks=db.get('banks');

        banks.find({},{},function(e,result){
                if(e){
                        return console.error(e);
                }

                if(result){
                        res.json(result);
                }
        });
});

router.get('/approve/invoicelist', function(req, res) {
        var db = req.db;
        var invoices = db.get('invoices');
        var dappusers = db.get('dappusers');
        var currentUserName = req.scfSession.userName;
        var currentUserAddress = req.scfSession.userAddress;

        invoices.aggregate([
                {
                        $lookup:{
                                from: "dappusers",
                                localField: "supplier",
                                foreignField: "ethAddress",
                                as: "supplier_info"
                        }
                },
                {   $unwind:"$supplier_info" },
                {
                        $lookup:{
                                from: "dappusers",
                                localField: "buyer",
                                foreignField: "ethAddress",
                                as: "buyer_info"
                        }
                },
                // $unwind used for getting data in object or for one record only
                {   $unwind:"$buyer_info" },

                {
                        $match:{
                                $and:[{"buyer" : currentUserAddress},{"status":0}]
                        }
                },
                // define which fields are you want to fetch
                {
                        $project:{
                                invoiceId : 1,
                                invoiceReference : 1,
                                amount : 1,
                                status : 1,
                                supplier : "$supplier_info.name",
                                buyer : "$buyer_info.name",
                        }
                }
        ],function(e,docs){
                if(e){
                        return console.error(e);
                }

                if(docs){
                        res.json(docs);
                } else {
                        res.send({ msg:'Error: No Data Found'});
                }
        });
});


router.get('/settle/invoicelist', function(req, res) {
        var db = req.db;
        var invoices = db.get('invoices');
        var dappusers = db.get('dappusers');
        var banks = db.get('banks');
        var currentUserName = req.scfSession.userName;
        var currentUserAddress = req.scfSession.userAddress;

        invoices.aggregate([
                {
                        $lookup:{
                                from: "dappusers",
                                localField: "supplier",
                                foreignField: "ethAddress",
                                as: "supplier_info"
                        }
                },
        {   $unwind:"$supplier_info" },
                {
                        $lookup:{
                                from: "banks",
                                localField: "bank",
                                foreignField: "ethAddress",
                                as: "bank_info"
                        }
                },
                {   $unwind:"$bank_info" },
                {
                        $lookup:{
                                from: "dappusers",
                                localField: "buyer",
                                foreignField: "ethAddress",
                                as: "buyer_info"
                        }
                },
                // $unwind used for getting data in object or for one record only
                {   $unwind:"$buyer_info" },

                {
                        $match:{
                                $and:[{"buyer" : currentUserAddress},{"status":2}]
                        }
                },
                // define which fields are you want to fetch
                {
                        $project:{
                                invoiceId : 1,
                                invoiceReference : 1,
                                amount : 1,
                                status : 1,
                                supplier : "$supplier_info.name",
                                bank : "$bank_info.name",
                                buyer : "$buyer_info.name",
								buyerEthId : "$buyer_info.ethAddress",
                        }
                }
        ],function(e,docs){
                if(e){
                        return console.error(e);
                }

                if(docs){
                        res.json(docs);
                } else {
                        res.send({ msg:'Error: No Data Found'});
                }
        });
});


router.get('/finance/invoicelist', function(req, res) {
        var db = req.db;
        var invoices = db.get('invoices');
        var dappusers = db.get('dappusers');
        var currentUserName = req.scfSession.userName;
        var currentUserAddress = req.scfSession.userAddress;

        invoices.aggregate([
                {
                        $lookup:{
                                from: "dappusers",
                                localField: "supplier",
                                foreignField: "ethAddress",
                                as: "supplier_info"
                        }
                },
                {   $unwind:"$supplier_info" },
                {
                        $lookup:{
                                from: "dappusers",
                                localField: "buyer",
                                foreignField: "ethAddress",
                                as: "buyer_info"
                        }
                },
                // $unwind used for getting data in object or for one record only
                {   $unwind:"$buyer_info" },

                {
                        $match:{
                                $and:[{"bank" : currentUserAddress},{"status":1}]
                        }
                },
                // define which fields are you want to fetch
                {
                        $project:{
                                invoiceId : 1,
                                invoiceReference : 1,
                                amount : 1,
                                status : 1,
                                supplier : "$supplier_info.name",
                                buyer : "$buyer_info.name",
								buyerEthId : "$buyer_info.ethAddress",
                        }
                }
        ],function(e,docs){
                if(e){
                        return console.error(e);
                }

                if(docs){
                        res.json(docs);
                } else {
                        res.send({ msg:'Error: No Data Found'});
                }
        });
});

/*
 * POST to approve.
 */
router.post('/approve/approveinvoice', function(req, res) {
        var currentUserName = req.scfSession.userName;
        var currentUserAddress = req.scfSession.userAddress;
        var invoiceid= req.body.invoiceId;
        var bank= req.body.bankaddress;

        wrapper.approveInvoice(currentUserAddress,invoiceid,bank,function(error,result){
                if(!error){
                        res.send({msg:result});
                } else{
                        res.send({msg:'Error: '+ error.message});
                }
        });
});

router.post('/finance/financeinvoice', function(req, res) {
        var currentUserName = req.scfSession.userName;
        var currentUserAddress = req.scfSession.userAddress;
        var invoiceid= req.body.invoiceId;

        creditcheck.checkcredit(mongoip,Number(req.body.amount),req.body.name,function(bool){
                if(bool){
                        wrapper.financeInvoice(currentUserAddress,invoiceid,bool,function(error,result){
                                if(!error){
                                        res.send({msg:result});
                                } else{
                                        res.send({msg:'Error: '+ error.message});
                                }
                        });
                } else{
                        wrapper.financeInvoice(currentUserAddress,invoiceid,bool,function(error,result){
						res.send({ msg:bool});
						});
                        
                }
        });
});

router.post('/settle/settleinvoice', function(req, res) {
        var currentUserName = req.scfSession.userName;
        var currentUserAddress = req.scfSession.userAddress;
        var invoiceid= req.body.invoiceId;

        creditcheck.settlecredit(mongoip,Number(req.body.amount),req.body.name,function(bool){
                if(bool){
                        wrapper.settleInvoice(currentUserAddress,invoiceid,true,function(error,result){
                                if(!error){
                                        res.send({msg:result});
                                } else{
                                        res.send({msg:'Error: '+ error.message});
                                }
                        });
                } else{
                        res.send({ msg:bool});
                }
        });
});

router.post('/view/viewinvoice', function(req, res) {
        var invoiceId= req.body.invoiceId;
        var db = req.db;
        var dappusers = db.get('dappusers');
        var banks= db.get('banks');

        wrapper.viewInvoice(invoiceId,function(error,result){
                if(!error){
                        dappusers.findOne({ethAddress: result[2]},'name', function(err, docs){
                                if(err){
                                        return console.error(err);
                                }

                                if(docs){
                                        result[2]=docs.name;
                                        dappusers.findOne({ethAddress: result[3]},'name', function(err, docs){
                                                if(err){
                                                        return console.error(err);
                                                }

                                                if(docs){
                                                        result[3]=docs.name;
                                                        banks.findOne({ethAddress: result[4]},'name', function(err, docs){
                                                                if(err){
                                                                        return console.error(err);
                                                                }
                                                                if(docs){
                                                                        result[4]=docs.name;
                                                                        res.send(result);
                                                                } else{
                                                                        result[4]="  NA  ";
                                                                        res.send(result);
                                                                }
                                                        });
                                                }
                                        });
                                }
                        });
                } else{
                        res.send({ msg:error});
                }
        });
});

router.post('/view/viewhistory', function(req, res) {
        var invId= req.body.invoiceId;
        var db = req.db;
        var invoices = db.get('invoices');

        invoices.findOne({invoiceId:Number(invId)},{createdate: 1, approvedate: 1, financedate: 1, settledate: 1},function(err, docs){
                if(err){
                        res.send({ msg:error });
                }
                if(docs){
                        res.json(docs);
                } else {
                        res.send({ msg:'Error: No Data Found'});
                }
        });
});

router.all('/*', function(req, res) {
        res.redirect("/scf");
});

module.exports = router;
