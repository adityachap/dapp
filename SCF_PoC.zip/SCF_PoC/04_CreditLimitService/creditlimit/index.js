var mongo = require('mongodb');
var monk = require('monk');
exports.checkcredit=function(mongoip,amount,ethAddress,fn){
	var mongodbs='';
	mongodbs+=mongoip+':27017/supplychaindb';
	var db = monk(mongodbs);
	var creditlimit=db.get('creditlimit');
	creditlimit.find({ethAddress:ethAddress},{},function(err,docs){
		if(amount<=docs[0].creditlimit){
			var newcredit=docs[0].creditlimit-amount;
			creditlimit.update({ethAddress:docs[0].ethAddress},{$set:{creditlimit:newcredit}},function(err,result){
				fn(true);
			});

		}else{
			fn(false);
		}
	});
}
exports.settlecredit=function(mongoip,amount,ethAddress,fn){
	var mongodbs='';
	mongodbs+=mongoip+':27017/supplychaindb';
	var db = monk(mongodbs);
	var creditlimit=db.get('creditlimit');
	creditlimit.find({ethAddress:ethAddress},{},function(err,docs){
		var newcredit=docs[0].creditlimit+amount;
		creditlimit.update({ethAddress:docs[0].ethAddress},{$set:{creditlimit:newcredit}},function(err,result){
			if(err===null){
				fn(true);
			}else{
				fn(false);
			}
		});
	});
}
